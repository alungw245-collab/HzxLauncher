package com.hzx.launcher

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {

    private lateinit var web: WebView
    private val iconCache = HashMap<String, ByteArray>()
    private var insetTop = 0
    private var insetBottom = 0

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            synchronized(iconCache) { iconCache.clear() }
            js("window.refreshApps&&refreshApps()")
        }
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Edge-to-edge hanya di Android 5.0+. Di Android 4.x pakai bar sistem biasa.
        if (Build.VERSION.SDK_INT >= 21) {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            window.statusBarColor = Color.TRANSPARENT
            window.navigationBarColor = Color.TRANSPARENT
        }

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#14172e"))

        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#14172e"))
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.isVerticalScrollBarEnabled = false
        web.isHorizontalScrollBarEnabled = false
        web.isHapticFeedbackEnabled = false
        web.setOnLongClickListener { true }
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = intercept(request.url)

            @Deprecated("Untuk Android 4.x - 4.4")
            override fun shouldInterceptRequest(view: WebView, url: String): WebResourceResponse? =
                intercept(Uri.parse(url))

            override fun onPageFinished(view: WebView?, url: String?) {
                applyInsets()
            }
        }

        root.addView(
            web,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 20) {
            root.setOnApplyWindowInsetsListener { _, ins ->
                val d = resources.displayMetrics.density
                insetTop = (ins.systemWindowInsetTop / d).toInt()
                insetBottom = (ins.systemWindowInsetBottom / d).toInt()
                applyInsets()
                ins
            }
        }

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(pkgReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(pkgReceiver, filter)
        }

        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.action == Intent.ACTION_MAIN) js("window.hzxHome&&hzxHome()")
    }

    @Deprecated("Launcher: tombol kembali tidak keluar dari layar utama")
    override fun onBackPressed() {
        js("window.hzxBack&&hzxBack()")
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(pkgReceiver)
        } catch (_: Exception) {
        }
        web.destroy()
        super.onDestroy()
    }

    private fun intercept(u: Uri): WebResourceResponse? {
        if (u.host == "hzx.local" && u.pathSegments.firstOrNull() == "icon") {
            val pkg = u.pathSegments.getOrNull(1) ?: return null
            val bytes = synchronized(iconCache) {
                iconCache.getOrPut(pkg) {
                    try {
                        iconBytes(pkg)
                    } catch (e: Exception) {
                        ByteArray(0)
                    }
                }
            }
            return WebResourceResponse("image/png", null, ByteArrayInputStream(bytes))
        }
        return null
    }

    private fun js(code: String) {
        runOnUiThread {
            if (Build.VERSION.SDK_INT >= 19) {
                web.evaluateJavascript(code, null)
            } else {
                // evaluateJavascript baru ada di Android 4.4
                web.loadUrl("javascript:void(function(){$code})()")
            }
        }
    }

    private fun applyInsets() {
        js("window.setInsets&&setInsets($insetTop,$insetBottom)")
    }

    private fun safeStart(i: Intent) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (_: Exception) {
        }
    }

    private fun iconBytes(pkg: String): ByteArray {
        val d = packageManager.getApplicationIcon(pkg)
        val s = 128
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        d.setBounds(0, 0, s, s)
        d.draw(c)
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        return out.toByteArray()
    }

    inner class Bridge {

        @JavascriptInterface
        fun getApps(): String {
            val pm = packageManager
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val seen = HashSet<String>()
            val arr = JSONArray()
            pm.queryIntentActivities(main, 0)
                .filter { it.activityInfo.packageName != packageName }
                .sortedBy { it.loadLabel(pm).toString().lowercase() }
                .forEach {
                    val p = it.activityInfo.packageName
                    if (seen.add(p)) {
                        arr.put(JSONObject().put("n", it.loadLabel(pm).toString()).put("p", p))
                    }
                }
            return arr.toString()
        }

        @JavascriptInterface
        fun launch(pkg: String) {
            runOnUiThread {
                packageManager.getLaunchIntentForPackage(pkg)?.let { safeStart(it) }
            }
        }

        @JavascriptInterface
        fun action(name: String) {
            runOnUiThread {
                val i = when (name) {
                    "phone" -> Intent(Intent.ACTION_DIAL)
                    "sms" -> Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING)
                    "browser" -> Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_BROWSER)
                    "camera" -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
                    "settings" -> Intent(Settings.ACTION_SETTINGS)
                    else -> null
                }
                if (i != null) safeStart(i)
            }
        }

        @JavascriptInterface
        fun info(pkg: String) {
            runOnUiThread {
                safeStart(
                    Intent(
                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.fromParts("package", pkg, null)
                    )
                )
            }
        }

        @JavascriptInterface
        fun uninstall(pkg: String) {
            runOnUiThread {
                safeStart(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))
            }
        }

        @JavascriptInterface
        fun search(q: String) {
            runOnUiThread {
                safeStart(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))
                    )
                )
            }
        }
    }
}
