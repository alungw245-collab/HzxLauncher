# HzX Launcher

Launcher Android (Kotlin + WebView) dengan tampilan ala Lenovo Vibe UI.
Daftar aplikasi diambil langsung dari HP, jadi semua aplikasi terpasang muncul di layar utama.

Minimal Android 4.2 (API 17). Belum dites di perangkat sungguhan.

## Build APK lewat GitHub
1. Buat repo baru di GitHub, upload semua isi folder ini (folder `.github` harus ikut).
2. Buka tab **Actions** -> workflow **Build APK** -> tunggu selesai (sekitar 3-5 menit).
3. Buka run yang sukses, unduh artifact **HzX-Launcher-APK** (isinya `app-debug.apk`).
4. Install APK di HP (aktifkan "Sumber tidak dikenal" di Setelan -> Keamanan).

## Jadikan layar utama
Tekan tombol Home, lalu pilih **HzX Launcher** -> **Selalu**.
Atau lewat Setelan -> Aplikasi (atau Aplikasi default) -> layar utama.

## Fitur
- Semua aplikasi terpasang tampil di halaman yang bisa digeser
- Dock 4 ikon (Telepon, Pesan, Browser, Kamera)
- Cari aplikasi langsung dari kolom pencarian, Enter untuk cari di Google
- Tekan lama ikon: Info aplikasi / Copot pemasangan
- Tekan lama area kosong: ganti wallpaper
- Daftar aplikasi otomatis diperbarui saat ada yang di-install atau dihapus

Tampilan ada di `app/src/main/assets/index.html` (HTML/JS/CSS versi lama agar jalan di WebView Android 4.2),
logika Android di `MainActivity.kt`.
