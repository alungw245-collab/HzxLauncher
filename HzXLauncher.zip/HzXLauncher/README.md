# HzX Launcher

Launcher Android (Kotlin + WebView) bergaya Samsung Galaxy S4.
Memakai ikon asli aplikasi dari HP. Minimal Android 4.2 (API 17). Belum dites di perangkat sungguhan.

## Build APK lewat GitHub
1. Upload `HzXLauncher.zip` ke repo GitHub, plus workflow di `.github/workflows/build.yml`
   (workflow yang meng-unzip lalu menjalankan `gradle assembleDebug`).
2. Buka tab **Actions** dan tunggu hijau, lalu unduh artifact **HzX-Launcher-APK**.
3. Install `app-debug.apk` di HP.

## Jadikan layar utama
Tekan tombol Home, lalu pilih **HzX Launcher** -> **Selalu**.

## Fitur
- Layar sambutan saat pertama dibuka (tombol MULAI)
- Layar utama: jam, kolom Google, ikon yang kamu pilih, dock (Telepon, Kontak, Pesan, Internet) dengan ikon asli HP
- Tombol Aplikasi (pojok kanan bawah) membuka semua aplikasi, dengan pencarian
- Di laci aplikasi, tekan lama ikon: Tambah ke layar utama / Info / Copot
- Di layar utama, tekan lama ikon lalu geser untuk memindahkan. Geser ke tepi kiri/kanan untuk pindah halaman.
  Jatuhkan di bar atas untuk Hapus (dari layar), Info aplikasi, atau Copot.
- Tekan lama area kosong: ganti wallpaper (bawaan atau dari galeri), atau atur ulang layar utama

Tampilan ada di `app/src/main/assets/index.html` (HTML/JS/CSS versi lama agar jalan di WebView Android 4.2),
logika Android di `MainActivity.kt`.
