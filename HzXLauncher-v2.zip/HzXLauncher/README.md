# HzX Launcher v2

Launcher Android (Kotlin + WebView) bergaya Smart Launcher. Minimal Android 4.2 (API 17).
Memakai ikon asli aplikasi dari HP. Belum dites di perangkat sungguhan.

## Build APK lewat GitHub
Upload `HzXLauncher.zip` ke repo, plus `.github/workflows/build.yml` (yang meng-unzip lalu `gradle assembleDebug`).
Tunggu hijau di tab Actions, unduh artifact **HzX-Launcher-APK**, install `app-debug.apk`.

## Jadikan layar utama
Tekan tombol Home, pilih **HzX Launcher** -> **Selalu**.

## Fitur
- Layar utama: jam, tanggal, baterai, widget Android, ikon favorit, dock 5 ikon, Smart search
- Geser ke atas: semua aplikasi. Smart search: cari aplikasi atau Google
- Geser ke kanan: keterangan HP, Adobe Flash Player, tombol Kustomisasi
- Kustomisasi (gaya Android 2.3): wallpaper, gaya/ukuran/nama ikon, ganti ikon dari galeri, widget, favorit, jam 24 jam
- Wallpaper: bawaan HzX, wallpaper HP, atau galeri. Semua bisa digeser dan dicubit untuk dipotong
- Tekan lama ikon di layar utama lalu geser: pindah, atau jatuhkan di bar atas (Hapus, Info, Ganti ikon, Copot)
- Tekan lama area kosong: buka Kustomisasi

Tampilan: `app/src/main/assets/index.html` (HTML/JS ES5 agar jalan di WebView Android 4.2).
Logika Android: `MainActivity.kt`.
