package com.hzx.launcher

import android.app.ActivityManager
import android.app.Activity
import android.app.WallpaperManager
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var widgetLayer: FrameLayout
    private lateinit var widgetMgr: AppWidgetManager
    private lateinit var widgetHost: AppWidgetHost
    private val widgetViews = LinkedHashMap<Int, AppWidgetHostView>()
    private val iconCache = HashMap<String, ByteArray>()
    private var insetTop = 0
    private var insetBottom = 0
    private var pendingId = -1
    private var pendingIconPkg = ""
    private var wTop = 0
    private var wLeft = 0
    private var wWidth = 0

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            synchronized(iconCache) { iconCache.clear() }
            js("window.refreshApps&&refreshApps()")
        }
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Edge-to-edge hanya di Android 5.0+. Di Android 4.x pakai bar sistem biasa.
        if (Build.VERSION.SDK_INT >= 21) {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            window.statusBarColor = Color.TRANSPARENT
            window.navigationBarColor = Color.TRANSPARENT
        }

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#0d0a2b"))

        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0d0a2b"))
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.isVerticalScrollBarEnabled = false
        web.isHorizontalScrollBarEnabled = false
        web.isHapticFeedbackEnabled = false
        web.setOnLongClickListener { true }
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = intercept(request.url)

            @Deprecated("Untuk Android 4.x - 4.4")
            override fun shouldInterceptRequest(view: WebView, url: String): WebResourceResponse? =
                intercept(Uri.parse(url))

            override fun onPageFinished(view: WebView?, url: String?) {
                applyInsets()
            }
        }

        root.addView(
            web,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        // Lapisan widget Android asli, di atas WebView
        widgetMgr = AppWidgetManager.getInstance(this)
        widgetHost = AppWidgetHost(this, 1024)
        widgetLayer = FrameLayout(this)
        root.addView(
            widgetLayer,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        loadSavedWidgets()

        setContentView(root)

        if (Build.VERSION.SDK_INT >= 20) {
            root.setOnApplyWindowInsetsListener { _, ins ->
                val d = resources.displayMetrics.density
                insetTop = (ins.systemWindowInsetTop / d).toInt()
                insetBottom = (ins.systemWindowInsetBottom / d).toInt()
                applyInsets()
                ins
            }
        }

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(pkgReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(pkgReceiver, filter)
        }

        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onStart() {
        super.onStart()
        try {
            widgetHost.startListening()
        } catch (e: Exception) {
        }
    }

    override fun onStop() {
        try {
            widgetHost.stopListening()
        } catch (e: Exception) {
        }
        super.onStop()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.action == Intent.ACTION_MAIN) js("window.hzxHome&&hzxHome()")
    }

    @Deprecated("Launcher: tombol kembali tidak keluar dari layar utama")
    override fun onBackPressed() {
        js("window.hzxBack&&hzxBack()")
    }

    @Deprecated("Dipakai untuk galeri dan widget")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val ok = resultCode == Activity.RESULT_OK
        when (requestCode) {
            REQ_WALL -> {
                val uri = data?.data
                if (ok && uri != null) {
                    Thread {
                        val saved = savePickedImage(uri)
                        js(
                            if (saved) "window.onPicked&&onPicked('pick')"
                            else "window.toastMsg&&toastMsg('Gambar tidak bisa dibuka')"
                        )
                    }.start()
                }
            }
            REQ_ICON -> {
                val uri = data?.data
                val pkg = pendingIconPkg
                if (ok && uri != null && pkg.isNotEmpty()) {
                    Thread {
                        val saved = saveCustomIcon(uri, pkg)
                        js(
                            if (saved) "window.onIconChanged&&onIconChanged(" + JSONObject.quote(pkg) + ")"
                            else "window.toastMsg&&toastMsg('Gambar tidak bisa dibuka')"
                        )
                    }.start()
                }
            }
            REQ_BIND -> {
                if (ok) afterBind(pendingId) else dropWidgetId(pendingId)
            }
            REQ_CONFIG -> {
                if (ok) finishAddWidget(pendingId) else dropWidgetId(pendingId)
            }
        }
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(pkgReceiver)
        } catch (e: Exception) {
        }
        web.destroy()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- web <-> file

    private fun intercept(u: Uri): WebResourceResponse? {
        if (u.host != "hzx.local") return null
        val segs = u.pathSegments
        when (segs.firstOrNull()) {
            "icon" -> {
                val pkg = segs.getOrNull(1) ?: return null
                val custom = File(filesDir, "icons/$pkg.png")
                if (custom.exists()) {
                    return WebResourceResponse("image/png", null, FileInputStream(custom))
                }
                val bytes = synchronized(iconCache) {
                    iconCache.getOrPut(pkg) {
                        try {
                            iconBytes(pkg)
                        } catch (e: Exception) {
                            ByteArray(0)
                        }
                    }
                }
                return WebResourceResponse("image/png", null, ByteArrayInputStream(bytes))
            }
            "wallpaper", "pick", "sys" -> {
                val name = when (segs[0]) {
                    "wallpaper" -> "wall.jpg"
                    "pick" -> "pick.jpg"
                    else -> "sys.jpg"
                }
                val f = File(filesDir, name)
                if (f.exists()) {
                    return WebResourceResponse("image/jpeg", null, FileInputStream(f))
                }
            }
        }
        return null
    }

    private fun js(code: String) {
        runOnUiThread {
            if (Build.VERSION.SDK_INT >= 19) {
                web.evaluateJavascript(code, null)
            } else {
                // evaluateJavascript baru ada di Android 4.4
                web.loadUrl("javascript:void(function(){$code})()")
            }
        }
    }

    private fun toast(msg: String) {
        js("window.toastMsg&&toastMsg(" + JSONObject.quote(msg) + ")")
    }

    private fun applyInsets() {
        js("window.setInsets&&setInsets($insetTop,$insetBottom)")
    }

    private fun safeStart(i: Intent) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
        }
    }

    private fun iconBytes(pkg: String): ByteArray {
        val d = packageManager.getApplicationIcon(pkg)
        val s = 128
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        d.setBounds(0, 0, s, s)
        d.draw(c)
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        return out.toByteArray()
    }

    private fun sampleFor(w: Int, h: Int, maxSide: Int): Int {
        var s = 1
        while (maxOf(w, h) / s > maxSide) s *= 2
        return s
    }

    private fun decodeUri(uri: Uri, maxSide: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        val opts = BitmapFactory.Options()
        opts.inSampleSize = sampleFor(bounds.outWidth, bounds.outHeight, maxSide)
        return contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    }

    private fun savePickedImage(uri: Uri): Boolean {
        return try {
            val bmp = decodeUri(uri, 1600) ?: return false
            FileOutputStream(File(filesDir, "pick.jpg")).use {
                bmp.compress(Bitmap.CompressFormat.JPEG, 90, it)
            }
            true
        } catch (e: Throwable) {
            false
        }
    }

    private fun saveCustomIcon(uri: Uri, pkg: String): Boolean {
        return try {
            val bmp = decodeUri(uri, 600) ?: return false
            val side = minOf(bmp.width, bmp.height)
            val x = (bmp.width - side) / 2
            val y = (bmp.height - side) / 2
            val sq = Bitmap.createBitmap(bmp, x, y, side, side)
            val out = Bitmap.createScaledBitmap(sq, 192, 192, true)
            val dir = File(filesDir, "icons")
            dir.mkdirs()
            FileOutputStream(File(dir, "$pkg.png")).use {
                out.compress(Bitmap.CompressFormat.PNG, 100, it)
            }
            synchronized(iconCache) { iconCache.remove(pkg) }
            true
        } catch (e: Throwable) {
            false
        }
    }

    private fun loadSource(src: String): Bitmap? {
        if (src.startsWith("asset:")) {
            val path = src.substring(6)
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            assets.open(path).use { BitmapFactory.decodeStream(it, null, bounds) }
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sampleFor(bounds.outWidth, bounds.outHeight, 2200)
            return assets.open(path).use { BitmapFactory.decodeStream(it, null, opts) }
        }
        val f = File(filesDir, if (src == "sys") "sys.jpg" else "pick.jpg")
        if (!f.exists()) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.absolutePath, bounds)
        val opts = BitmapFactory.Options()
        opts.inSampleSize = sampleFor(bounds.outWidth, bounds.outHeight, 2200)
        return BitmapFactory.decodeFile(f.absolutePath, opts)
    }

    private fun drawableToBitmap(d: Drawable, maxSide: Int): Bitmap {
        var w = d.intrinsicWidth
        var h = d.intrinsicHeight
        if (w <= 0 || h <= 0) {
            w = 720
            h = 1280
        }
        val scale = minOf(1f, maxSide.toFloat() / maxOf(w, h).toFloat())
        val bw = maxOf(1, (w * scale).toInt())
        val bh = maxOf(1, (h * scale).toInt())
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        d.setBounds(0, 0, bw, bh)
        d.draw(c)
        return bmp
    }

    private fun batteryPercent(): Int {
        return try {
            val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            if (level < 0 || scale <= 0) -1 else level * 100 / scale
        } catch (e: Exception) {
            -1
        }
    }

    @Suppress("DEPRECATION")
    private fun storageInfo(): LongArray {
        val st = StatFs(Environment.getDataDirectory().path)
        return if (Build.VERSION.SDK_INT >= 18) {
            longArrayOf(
                st.blockCountLong * st.blockSizeLong,
                st.availableBlocksLong * st.blockSizeLong
            )
        } else {
            longArrayOf(
                st.blockCount.toLong() * st.blockSize.toLong(),
                st.availableBlocks.toLong() * st.blockSize.toLong()
            )
        }
    }

    // ---------------------------------------------------------------- widget

    @Suppress("DEPRECATION")
    private fun widgetLabel(p: AppWidgetProviderInfo): String {
        return try {
            if (Build.VERSION.SDK_INT >= 21) {
                p.loadLabel(packageManager) ?: p.provider.packageName
            } else {
                p.label ?: p.provider.packageName
            }
        } catch (e: Throwable) {
            p.provider.packageName
        }
    }

    private fun widgetHeightDp(info: AppWidgetProviderInfo?): Int {
        val d = resources.displayMetrics.density
        val h = if (info != null) (info.minHeight / d).toInt() else 110
        return minOf(260, maxOf(70, h))
    }

    private fun saveWidgets() {
        getSharedPreferences("hzx", Context.MODE_PRIVATE).edit()
            .putString("widgets", widgetViews.keys.joinToString(","))
            .apply()
    }

    private fun loadSavedWidgets() {
        val s = getSharedPreferences("hzx", Context.MODE_PRIVATE).getString("widgets", "") ?: ""
        for (part in s.split(",")) {
            val id = part.toIntOrNull() ?: continue
            val info = widgetMgr.getAppWidgetInfo(id) ?: continue
            try {
                val hv = widgetHost.createView(this, id, info)
                widgetViews[id] = hv
                widgetLayer.addView(hv, FrameLayout.LayoutParams(1, 1))
            } catch (e: Exception) {
            }
        }
    }

    private fun doLayoutWidgets() {
        val d = resources.displayMetrics.density
        var y = (wTop * d).toInt()
        for (hv in widgetViews.values) {
            val h = (widgetHeightDp(hv.appWidgetInfo) * d).toInt()
            val lp = FrameLayout.LayoutParams((wWidth * d).toInt(), h)
            lp.leftMargin = (wLeft * d).toInt()
            lp.topMargin = y
            hv.layoutParams = lp
            y += h + (8 * d).toInt()
        }
    }

    private fun dropWidgetId(id: Int) {
        try {
            if (id >= 0) widgetHost.deleteAppWidgetId(id)
        } catch (e: Exception) {
        }
    }

    private fun afterBind(id: Int) {
        val info = widgetMgr.getAppWidgetInfo(id)
        if (info == null) {
            dropWidgetId(id)
            toast("Widget gagal ditambahkan")
            return
        }
        if (info.configure != null) {
            pendingId = id
            try {
                widgetHost.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null)
            } catch (e: Exception) {
                finishAddWidget(id)
            }
        } else {
            finishAddWidget(id)
        }
    }

    private fun finishAddWidget(id: Int) {
        val info = widgetMgr.getAppWidgetInfo(id)
        if (info == null) {
            dropWidgetId(id)
            return
        }
        try {
            val hv = widgetHost.createView(this, id, info)
            widgetViews[id] = hv
            widgetLayer.addView(hv, FrameLayout.LayoutParams(1, 1))
            saveWidgets()
            doLayoutWidgets()
            js("window.onWidgetsChanged&&onWidgetsChanged()")
        } catch (e: Exception) {
            dropWidgetId(id)
            toast("Widget gagal ditambahkan")
        }
    }

    // ---------------------------------------------------------------- jembatan JS

    inner class Bridge {

        @JavascriptInterface
        fun getApps(): String {
            val pm = packageManager
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val seen = HashSet<String>()
            val arr = JSONArray()
            pm.queryIntentActivities(main, 0)
                .filter { it.activityInfo.packageName != packageName }
                .sortedBy { it.loadLabel(pm).toString().lowercase() }
                .forEach {
                    val p = it.activityInfo.packageName
                    if (seen.add(p)) {
                        arr.put(JSONObject().put("n", it.loadLabel(pm).toString()).put("p", p))
                    }
                }
            return arr.toString()
        }

        /** Aplikasi bawaan HP untuk dock beserta ikon aslinya. */
        @JavascriptInterface
        fun getDock(): String {
            val pm = packageManager
            val defs = listOf(
                Triple("phone", "Telepon", Intent(Intent.ACTION_DIAL)),
                Triple(
                    "contacts", "Kontak",
                    Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CONTACTS)
                ),
                Triple(
                    "sms", "Pesan",
                    Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING)
                ),
                Triple(
                    "browser", "Internet",
                    Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_BROWSER)
                ),
                Triple("camera", "Kamera", Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
            )
            val arr = JSONArray()
            for ((act, name, intent) in defs) {
                var pkg = ""
                try {
                    pkg = pm.resolveActivity(intent, 0)?.activityInfo?.packageName ?: ""
                    if (pkg.isEmpty() || pkg == "android") {
                        pkg = pm.queryIntentActivities(intent, 0)
                            .firstOrNull { it.activityInfo.packageName != "android" }
                            ?.activityInfo?.packageName ?: ""
                    }
                } catch (e: Exception) {
                }
                arr.put(JSONObject().put("act", act).put("n", name).put("p", pkg))
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun launch(pkg: String) {
            runOnUiThread {
                packageManager.getLaunchIntentForPackage(pkg)?.let { safeStart(it) }
            }
        }

        @JavascriptInterface
        fun action(name: String) {
            runOnUiThread {
                val i = when (name) {
                    "phone" -> Intent(Intent.ACTION_DIAL)
                    "contacts" -> Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CONTACTS)
                    "sms" -> Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING)
                    "browser" -> Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_BROWSER)
                    "camera" -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
                    "settings" -> Intent(Settings.ACTION_SETTINGS)
                    else -> null
                }
                if (i != null) safeStart(i)
            }
        }

        @JavascriptInterface
        fun info(pkg: String) {
            runOnUiThread {
                safeStart(
                    Intent(
                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.fromParts("package", pkg, null)
                    )
                )
            }
        }

        @JavascriptInterface
        fun uninstall(pkg: String) {
            runOnUiThread {
                safeStart(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))
            }
        }

        @JavascriptInterface
        fun search(q: String) {
            runOnUiThread {
                safeStart(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))
                    )
                )
            }
        }

        @JavascriptInterface
        fun getInfo(): String {
            val o = JSONObject()
            o.put("model", Build.MODEL)
            o.put("manu", Build.MANUFACTURER)
            o.put("release", Build.VERSION.RELEASE)
            o.put("sdk", Build.VERSION.SDK_INT)
            o.put("battery", batteryPercent())
            try {
                val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val mi = ActivityManager.MemoryInfo()
                am.getMemoryInfo(mi)
                o.put("ram", mi.totalMem / 1048576L)
            } catch (e: Throwable) {
            }
            try {
                val st = storageInfo()
                o.put("disk", st[0] / 1048576L)
                o.put("diskFree", st[1] / 1048576L)
            } catch (e: Throwable) {
            }
            return o.toString()
        }

        @JavascriptInterface
        fun getBattery(): Int {
            return batteryPercent()
        }

        @JavascriptInterface
        fun launchFlash() {
            runOnUiThread {
                val i = packageManager.getLaunchIntentForPackage("com.adobe.flashplayer")
                if (i != null) {
                    safeStart(i)
                } else {
                    toast("Adobe Flash Player belum terpasang di HP ini")
                }
            }
        }

        @JavascriptInterface
        fun openHomeSettings() {
            runOnUiThread {
                try {
                    val i = Intent("android.settings.HOME_SETTINGS")
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(i)
                } catch (e: Exception) {
                    safeStart(Intent(Settings.ACTION_SETTINGS))
                }
            }
        }

        // ---- wallpaper

        @JavascriptInterface
        fun pickWallpaper() {
            runOnUiThread {
                try {
                    val i = Intent(Intent.ACTION_GET_CONTENT).setType("image/*")
                    @Suppress("DEPRECATION")
                    startActivityForResult(Intent.createChooser(i, "Pilih gambar"), REQ_WALL)
                } catch (e: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun prepareSysWall() {
            Thread {
                var ok = false
                try {
                    val wm = WallpaperManager.getInstance(this@MainActivity)
                    val dr = wm.drawable
                    if (dr != null) {
                        val bmp = drawableToBitmap(dr, 1600)
                        FileOutputStream(File(filesDir, "sys.jpg")).use {
                            bmp.compress(Bitmap.CompressFormat.JPEG, 90, it)
                        }
                        ok = true
                    }
                } catch (e: Throwable) {
                }
                js(
                    if (ok) "window.onPicked&&onPicked('sys')"
                    else "window.toastMsg&&toastMsg('Wallpaper HP tidak bisa diambil')"
                )
            }.start()
        }

        @JavascriptInterface
        fun applyWallpaper(
            src: String,
            fx: Double,
            fy: Double,
            fw: Double,
            fh: Double,
            aspect: Double
        ) {
            Thread {
                var ok = false
                try {
                    val bmp = loadSource(src)
                    if (bmp != null) {
                        val bw = bmp.width
                        val bh = bmp.height
                        val x = (fx * bw).toInt().coerceIn(0, bw - 1)
                        val y = (fy * bh).toInt().coerceIn(0, bh - 1)
                        val w = (fw * bw).toInt().coerceIn(1, bw - x)
                        val h = (fh * bh).toInt().coerceIn(1, bh - y)
                        val part = Bitmap.createBitmap(bmp, x, y, w, h)
                        val outW = 720
                        val outH = (outW * aspect).toInt().coerceIn(320, 2400)
                        val out = Bitmap.createScaledBitmap(part, outW, outH, true)
                        FileOutputStream(File(filesDir, "wall.jpg")).use {
                            out.compress(Bitmap.CompressFormat.JPEG, 90, it)
                        }
                        ok = true
                    }
                } catch (e: Throwable) {
                }
                js(
                    if (ok) "window.onWallpaper&&onWallpaper()"
                    else "window.toastMsg&&toastMsg('Gagal memakai wallpaper')"
                )
            }.start()
        }

        // ---- ikon

        @JavascriptInterface
        fun pickIcon(pkg: String) {
            runOnUiThread {
                try {
                    pendingIconPkg = pkg
                    val i = Intent(Intent.ACTION_GET_CONTENT).setType("image/*")
                    @Suppress("DEPRECATION")
                    startActivityForResult(Intent.createChooser(i, "Pilih gambar ikon"), REQ_ICON)
                } catch (e: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun resetIcon(pkg: String) {
            try {
                File(filesDir, "icons/$pkg.png").delete()
            } catch (e: Exception) {
            }
            synchronized(iconCache) { iconCache.remove(pkg) }
        }

        // ---- widget

        @JavascriptInterface
        fun getWidgetProviders(): String {
            val d = resources.displayMetrics.density
            val arr = JSONArray()
            try {
                for (p in widgetMgr.installedProviders) {
                    arr.put(
                        JSONObject()
                            .put("n", widgetLabel(p))
                            .put("pkg", p.provider.packageName)
                            .put("cls", p.provider.className)
                            .put("h", (p.minHeight / d).toInt())
                    )
                }
            } catch (e: Exception) {
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun getWidgets(): String {
            val arr = JSONArray()
            for ((id, hv) in widgetViews) {
                val info = hv.appWidgetInfo
                arr.put(
                    JSONObject()
                        .put("id", id)
                        .put("n", if (info != null) widgetLabel(info) else "Widget")
                        .put("h", widgetHeightDp(info))
                )
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun addWidget(pkg: String, cls: String) {
            runOnUiThread {
                try {
                    val cn = ComponentName(pkg, cls)
                    val id = widgetHost.allocateAppWidgetId()
                    if (widgetMgr.bindAppWidgetIdIfAllowed(id, cn)) {
                        afterBind(id)
                    } else {
                        pendingId = id
                        val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                        i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                        i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, cn)
                        @Suppress("DEPRECATION")
                        startActivityForResult(i, REQ_BIND)
                    }
                } catch (e: Exception) {
                    toast("Widget tidak bisa ditambahkan")
                }
            }
        }

        @JavascriptInterface
        fun removeWidget(id: Int) {
            runOnUiThread {
                dropWidgetId(id)
                val hv = widgetViews.remove(id)
                if (hv != null) widgetLayer.removeView(hv)
                saveWidgets()
                doLayoutWidgets()
                js("window.onWidgetsChanged&&onWidgetsChanged()")
            }
        }

        @JavascriptInterface
        fun layoutWidgets(top: Int, left: Int, width: Int) {
            runOnUiThread {
                wTop = top
                wLeft = left
                wWidth = width
                doLayoutWidgets()
            }
        }

        @JavascriptInterface
        fun widgetsVisible(show: Boolean) {
            runOnUiThread {
                widgetLayer.visibility = if (show) View.VISIBLE else View.INVISIBLE
            }
        }
    }

    companion object {
        private const val REQ_WALL = 77
        private const val REQ_ICON = 78
        private const val REQ_BIND = 79
        private const val REQ_CONFIG = 80
    }
}
